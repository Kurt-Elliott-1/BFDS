Currently no source, (seekep.inc) not included.

Use the UNIT and Object files from F_Mirc
