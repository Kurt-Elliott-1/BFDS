//<c>   Copyright 1998-2000 by Gerry J. Danen; all rights reserved.

//<t>   Verify Boot Date

#include"gd_tools.h"
#include"gd_nw.h"


#define CHECKdate       20000101L


void    main( int argc, char *argv[] )
{
    INT32       yyyymmdd ;
    INT16       yyyy, mm, dd ;
    UCHAR       sMsg[81], sFormattedDate[12] ;

    FormatDate( CHECKdate, sFormattedDate, 9 );

    dt_getsystemdate( &yyyymmdd, &yyyy, &mm, &dd );
    if ( yyyymmdd < CHECKdate )
    {
        printf( "PROBLEM: System date less than %s\a\n", sFormattedDate );
//      sprintf( sMsg, "! System date less than %s", sFormattedDate );
//      nw_logmsg( sMsg );
        exit( 11 );
    }

    printf( "System date seems OK.\n" );
    exit( 0 );
}
