
/* TURBO C source code for envset.com.*/

/*                           Version 1.0                         */
/*                           August, 1989                        */
/*                        (c) 1989 John Sloan.                   */

/*                (John Sloan, Compuserve 73727,2162)            */

#include <stdio.h>
#include <string.h>
main( int argc, char *argv[] )
{

    char *a;              /* this string will contain the DOS
                             SET command string. */

    char *b;              /* the "b" variable will be the value that
                             the environment variable is set to. */

    FILE *c;              /* this will be a file pointer to
                             a temporary batch file that will
                             contain the DOS "SET" command
                             required to make the chosen
                             variable available to the batch
                             file. */


    c=fopen(argv[1],"w"); /* open the temporary batch file. */

    gets(b);              /* get the input from the console... */

    strcpy(a,"set ");     /* copy "SET " to the SET command string. */

    strcat(a,argv[2]);    /* copy the temporary environment variable
                             name to the SET command input string. */

    strcat(a,"=");        /* append an equals sign to the SET command
                             string. */

    strcat(a,b);          /* append the input to the SET command string. */

    fputs(a,c);           /* Put the DOS SET command in the temporary batch
                             file. */

    flushall();           /* Flush the temporary batch file. */
    fclose(c);            /* Close the temporary batch file. */
}
