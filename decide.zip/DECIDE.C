/* DECIDE - Directory Analyzer & Batch file enhancer
 * Copyright 1997 Edward Brophy
 * Freely Distributable.
 */
#include <stdlib.h>
#include <stdio.h>
#include <dos.h>
#include <dir.h>
#include <time.h>
#include <string.h>

static char help_text[] = {"\n\
DECIDE [[drive:][path]filename] quality [G|L] quantity\n\
\n\
Quality is the aspect of the directory to be analyzed:\n\
 -Time     [S] = Seconds           [M] = Minutes\n\
           [H] = Hours             [D] = Days\n\
 -Size  [B[T]] = Bytes (or Total of Bytes matching filename)\n\
        [K[T]] = Kiloytes (or Total of Kilobytes matching filename)\n\
 -Count    [C] = Count of all files matching filename.\n\
[G] = File(s) quality matching filename is Greater than quantity.\n\
[L] = File(s) quality matching filename is Lesser than quantity.\n\
Quantity is the target number of the quality being measured,\n\
    i.e. # of seconds, bytes or files.\n\
Example:  DECIDE C:\\TEMP\\~*.* C G 20\n\
Example returns errorlevel 0 if the # of files is less than 21,\n\
                           1 if the # of files is more than 20,\n\
                           255 if any error occurs.\n\n\
Created by Edward Brophy 1997 - Freely Distributable.\n" };

main(int argc, char *argv[])
{
char
	path[MAXPATH],		/* Path we are searching */
	mode = 0,               /* Greater or less than */
	torf = 0,               /* Completed flag--True or False */
	quality = 0,		/* Decision criteria--2nd argument */
	total = 0,		/* Total file sizes */
	badopt = 0;		/* A bad command option was detected */

int 
	   i, attrs = 39;
char 
	temp[MAXPATH];
					    
struct ffblk 
	fdata;                  /* Holder for directory file data */

unsigned
        fflag = 0,              /* flag file for fnsplit */
	filecount = 0;		/* Count of files processed */

unsigned long
	   mult = 1,               /* Unit multiplier */
	   quantity = 0,           /* 4th argument */
	   number = 0;             /* running total */

time_t
        target,
        t;                 /* time holder */        

struct tm 
        fdate;

    /* Get execution time for program */

	   t = time(NULL);

    /* Parse command options */

	   i = 0;
	   if (argc != 5) i = (badopt = 5);
	   while (i < 4) {
		  i++;
		  if (badopt) continue;   /* drop out of loop */
		  switch(i) {
			 case 1 :
                    if (strlen(argv[i]) > 65) badopt = i;
                    else {
                        strcpy(path, argv[i]);
			    fflag = fnsplit(path, temp, temp, temp, temp);
                        if (!(fflag & WILDCARDS))
                            if (!(fflag & FILENAME)) badopt = i; }
                    break;
                case 2 :
                    argv[i] = strupr(argv[i]);
				if (!strcmp(argv[i],"S")) {
                        quality = 1;     /* time */
                        mult = 1;       /* seconds */
                        break; }
                    if (!strcmp(argv[i],"M")) {
                        quality = 1;
                        mult = 60;      /* minutes */
                        break; }
                    if (!strcmp(argv[i],"H")) {
                        quality = 1;
                        mult = 3600;    /* hours */
                        break; }
                    if (!strcmp(argv[i],"D")) {
                        quality = 1;
                        mult = 86400;   /* days */
                        break; }
                    if (!strcmp(argv[i],"B")) {
                        quality = 2;     /* size */
                        mult = 1;       /* bytes */
                        break; }
                    if (!strcmp(argv[i],"K")) {
                        quality = 2;
                        mult = 1024;    /* kilobytes */
                        break; }
                    if (!strcmp(argv[i],"BT")) {
                        total = 1;      /* total of all file sizes */
                        quality = 2;
                        mult = 1;       /* bytes */
                        break; }
                    if (!strcmp(argv[i],"KT")) {
                        total = 1;
                        quality = 2;
                        mult = 1024;    /* kilobytes */
                        break; }
                    if (!strcmp(argv[i],"C")) {
                        quality = 3;     /* file count */
                        mult = 1;
                        break; }
                    badopt = i;
                    break;
                case 3 : 
                    argv[i] = strupr(argv[i]);
				if (!strcmp(argv[i],"G")) {
				    mode = 1;       /* greater than */
				    break; }
				if (!strcmp(argv[i],"L")) {
                        mode = 0;       /* lesser than */
                        break; }
                    badopt = i;
                    break;
                case 4 :
				if (!strcmp(argv[i],"0")) {
					quantity = 0;
					if (quality == 1) badopt = i; }
				else {
				    quantity = atol(argv[i]);
				    if (!quantity) badopt = i; }
			 }
		  }
	if (badopt) {
            if (badopt < 5) printf("\nBad parameter: %s\n",argv[badopt]);
            else printf("\nBad number of parameters.\n");
            fputs(help_text, stdout);
            exit(255); }
		
        switch(quality) {
            case 1:
                target = t;  /* still set from start of program */
                target -= quantity * mult;
                break;
            case 2:
            case 3:
                quantity *= mult; }

	/* Search for files & handle show/set attributes */

	if(!findfirst(path, &fdata, attrs)) do {
		switch(quality) {
		    case 1:
				fdate.tm_year = (fdata.ff_fdate >> 9) + 80;
				fdate.tm_mon  = ((fdata.ff_fdate >> 5) & 0x0f) -1;
				fdate.tm_mday = fdata.ff_fdate & 0x1f;
				fdate.tm_hour = (fdata.ff_ftime >> 11);
				fdate.tm_min  = (fdata.ff_ftime >> 5) & 63;
				fdate.tm_sec  = 1;
				fdate.tm_isdst = -1;
				if (mktime(&fdate) == -1)
				fdate.tm_wday = 7;
	   /*  call mktime to fill in the weekday field of the structure */
				t = mktime(&fdate);
				if (mode) torf = target > t;
				else torf = target < t;
				break;
		    case 2:
				    if (total) number += fdata.ff_fsize;
                        else {
				   number = fdata.ff_fsize;
                		if (mode) torf = number > quantity;
				   else torf = number < quantity; }
				    break;
				case 3:
				    ++filecount;
				}
		    }
		while(!findnext(&fdata) & !torf);

		if (total) {
		    if (mode) torf = number > quantity;
		    else torf = number < quantity; }
		if (quality == 3) {
			if (mode) torf = filecount > quantity;
			else torf = filecount < quantity; }

	/* Display result messages */

return(torf);
}

