You can use the following command line switches:

/A to activate
/D to deactivate

For Windows Vista you must run it as an administrator:
	1) Right-Click the program
	2) Choose Run as administrator.


