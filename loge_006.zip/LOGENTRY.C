/*				 Write a passed entry to a log				*/
/* Format of call is: LOGENTRY filename a xxxxxxx xxxxxxxxx xxxxxx	*/
/* filename is the file that will be appended					*/
/* a is the loglevel of the message (1 character)					*/
/* xxxxxxxx is the message to be written to the file				*/
/* 0.05 Added display for info being written to file				*/
/* 0.06 Added Date and Time to log entry						*/
#include <stdio.h>
#include <dos.h>
void main(int numparms, char *parm[])
{
struct date today;
struct time now;

char version[]="0.06",
	months[12][4] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};

int	i;

FILE	*log_fp;

	getdate(&today);
	gettime(&now);
	log_fp = fopen(parm[1], "a");
	printf ("Logentry V%s %s %s", version, parm[1], parm[2]);
	fprintf(log_fp, "%1s %02d %3s ", parm[2], today.da_day, months[today.da_mon-1]);
	fprintf(log_fp, "%02d:%02d:%02d", now.ti_hour, now.ti_min, now.ti_sec);
	for (i=3; i<numparms; i++)
	{
		fprintf(log_fp, " %s", parm[i]);
		printf(" %s", parm[i]);
	}
	fprintf(log_fp, "\n");
	printf("\n");
	fclose (log_fp);
	exit(0);
}