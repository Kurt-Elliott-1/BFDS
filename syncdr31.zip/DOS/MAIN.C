#include <errno.h>
#include "syncdir.h"

int sysError()
{
  return errno;
}

int hard_handler(int err, int ax, int bp, int si)
{
  return 3; /* FAIL */
}

int main(int argc, char **argv)
{
  int ret;

  harderr(hard_handler);
  ret = syncdir(argc, argv);

  return ret;
}
