#include "ntui.h"
#include "..\shared\syncdir.h"
#include <commctrl.h>
#include "progress.h"

int sysError()
{
  return errno;
}

int main(int argc, char **argv)
{
  int ret;
  InitCommonControls();
  progressRegister();
  
  ret = syncdir(argc, argv);

  return ret;
}
