#include "ntui.h"
#include <stdio.h>
//
// fix number (1) make less than 6 digits (add 'k' or 'm'), (2) add comma
//
const char *fixNumber(char *dst, UINT32 n)
{
  char ch = ' ';
  if (n > 999999)
  {
    n /= 1000;
    ch = 'K';
    if (n > 999999)
    {
      n /= 1000;
      ch = 'M';
    }
  }
  if (n < 1000)
    sprintf(dst, "    %3d%c", n, ch);
  else
    sprintf(dst, "%3d,%03d%c", n / 1000, n % 1000, ch);
  return dst;
}

